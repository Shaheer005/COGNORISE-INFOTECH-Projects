const baseUrl = 'http://localhost:3001/tasks';

async function fetchTasks() {
    const response = await fetch(baseUrl);
    const tasks = await response.json();
    return tasks;
}

async function renderTasks() {
    const tasks = await fetchTasks();
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = '';
    tasks.forEach((taskObj, index) => {
        const { task } = taskObj;
        const li = document.createElement('li');
        li.innerHTML = `
            <span class="task-text">${task}</span>
            <input class="edit-input" style="display: none;" type="text" value="${task}">
            <button class="edit-btn" onclick="editTask(${index})"><i class="fas fa-edit"></i></button>
            <button class="save-btn" style="display: none;" onclick="saveTask(${index})"><i class="fas fa-save"></i></button>
            <button class="delete-btn" onclick="deleteTask(${index})"><i class="fas fa-trash-alt"></i></button>
        `;
        taskList.appendChild(li);
    });
}

async function addTask() {
    const taskInput = document.getElementById('taskInput');
    const task = taskInput.value.trim();
    if (task) {
        const response = await fetch(baseUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ task })
        });
        console.log('Add response:', await response.json());
        taskInput.value = '';
        renderTasks();
    }
}

async function editTask(index) {
    const taskList = document.getElementById('taskList');
    const taskItem = taskList.children[index];
    const taskText = taskItem.querySelector('.task-text');
    const editInput = taskItem.querySelector('.edit-input');
    const editBtn = taskItem.querySelector('.edit-btn');
    const saveBtn = taskItem.querySelector('.save-btn');

    taskText.style.display = 'none';
    editInput.style.display = 'inline';
    editBtn.style.display = 'none';
    saveBtn.style.display = 'inline';
}

async function saveTask(index) {
    const taskList = document.getElementById('taskList');
    const taskItem = taskList.children[index];
    const editInput = taskItem.querySelector('.edit-input');
    const newTask = editInput.value.trim();

    if (newTask) {
        const response = await fetch(`${baseUrl}/${index}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ task: newTask })
        });
        console.log('Save response:', await response.json());
        renderTasks();
    }
}

async function deleteTask(index) {
    const response = await fetch(`${baseUrl}/${index}`, {
        method: 'DELETE'
    });
    console.log('Delete response:', await response.json());
    renderTasks();
}

document.addEventListener('DOMContentLoaded', () => {
    const addTaskBtn = document.getElementById('addTaskBtn');
    addTaskBtn.addEventListener('click', addTask);

    const taskInput = document.getElementById('taskInput');
    taskInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addTask();
        }
    });

    renderTasks();
});

// Ensure the functions are available globally
window.editTask = editTask;
window.saveTask = saveTask;
window.deleteTask = deleteTask;
