const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 3001;

app.use(bodyParser.json());
app.use(cors());

let tasks = [];

app.get('/tasks', (req, res) => {
    res.json(tasks);
});

app.post('/tasks', (req, res) => {
    const { task } = req.body;
    if (!task) {
        return res.status(400).json({ error: 'Task is required' });
    }
    tasks.push({ task });
    res.status(201).json({ message: 'Task added', tasks });
});

app.put('/tasks/:index', (req, res) => {
    const index = req.params.index;
    const { task } = req.body;
    if (!task) {
        return res.status(400).json({ error: 'Task is required' });
    }
    tasks[index].task = task;
    res.json({ message: 'Task updated', tasks });
});

app.delete('/tasks/:index', (req, res) => {
    const index = req.params.index;
    tasks.splice(index, 1);
    res.json({ message: 'Task deleted', tasks });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
