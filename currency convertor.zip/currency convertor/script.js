// Include API for currency conversion
const api = "https://api.exchangerate-api.com/v4/latest/USD";

// Selecting different controls
var search = document.querySelector(".searchBox");
var convert = document.querySelector(".convert");
var fromCurrency = document.querySelector(".from");
var toCurrency = document.querySelector(".to");
var finalValue = document.querySelector(".finalValue");
var finalAmount = document.getElementById("finalAmount");

var resultFrom;
var resultTo;
var searchValue;

// Event when the "from" currency is changed
fromCurrency.addEventListener('change', (event) => {
    resultFrom = event.target.value;
});

// Event when the "to" currency is changed
toCurrency.addEventListener('change', (event) => {
    resultTo = event.target.value;
});

// Event to update the amount value
search.addEventListener('input', updateValue);

function updateValue(e) {
    searchValue = e.target.value;
}

// When user clicks, call function to get results
convert.addEventListener("click", getResults);

function getResults() {
    fetch(`${api}`)
        .then(response => response.json())
        .then(currency => {
            displayResults(currency);
        })
        .catch(error => console.error("Error fetching the exchange rates:", error));
}

// Display results after conversion
function displayResults(currency) {
    if (!resultFrom || !resultTo || !searchValue) {
        alert("Please select currencies and enter an amount to convert.");
        return;
    }

    let fromRate = currency.rates[resultFrom];
    let toRate = currency.rates[resultTo];

    if (fromRate && toRate) {
        finalValue.innerHTML = ((toRate / fromRate) * searchValue).toFixed(2);
        finalAmount.style.display = "block";
    } else {
        alert("Invalid currency selection. Please choose valid currencies.");
    }
}

// When user clicks on reset button
function clearVal() {
    window.location.reload();
}
